<!-- Ce module FAQ a été créé durant un stage à ZOOMACOM par un étudiant en formation -->
<!-- à la Design Tech Academie Télécom Saint-Etienne à partir du module Forum d'Agora-Project -->

<script type="text/javascript">
////	Resize
lightboxWidth(700);
</script>

<style>
[name='title']					{margin-bottom:20px !important;}
.vEvtOptionsLabel img			{max-height:15px;}
.vMessageQuoted					{overflow:auto; max-height:100px; margin-bottom:20px; opacity:0.7; background:#eee; border-radius:5px; padding:5px; font-style:italic; font-size:95%;}
.vMessageQuoted [src*='quote']	{float:right;}
.vSubjectMessInfos				{box-shadow:0 6px 6px -6px #999;}
.vSubjectMessDescription		{margin-top:10px;}
</style>

<form action="index.php" method="post" onsubmit="return finalFormControl()" enctype="multipart/form-data" class="lightboxContent">

	<!--MESSAGE A CITER?-->
	<?php if(!empty($messageParent)){ ?>
	<div class="vMessageQuoted">
		<img src="app/img/forum/quote.png">
		<span class="vSubjectMessInfos"><?= $messageParent->title ?></span>
		<div class="vSubjectMessDescription"><?= $messageParent->description ?></div>
	</div>
	<?php } ?>

	<!--TITRE & DESCRIPTION (EDITOR)-->
	<input type="text" name="title" value="<?= $curObj->title ?>" class="textBig" placeholder="<?= Txt::trad("title") ?>">
	<textarea name="description"><?= $curObj->description ?></textarea>

	<!--"_idMessageParent" & MENU COMMUN-->
	<?php if(Req::isParam("_idMessageParent")){ ?>
	<input type="hidden" name="_idMessageParent" value="<?= Req::getParam("_idMessageParent") ?>">
	<?php } ?>
	<?= $curObj->menuEdit() ?>
</form>
