<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/

// Ce module FAQ a été créé durant un stage à ZOOMACOM par un étudiant en formation
// à la Design Tech Academie Télécom Saint-Etienne à partir du module Forum d'Agora-Project

/*
 * Controleur du module "Forum"
 */

class CtrlFaq extends Ctrl
{
	const moduleName="faq";
	public static $moduleOptions=["ajout_sujet_admin"];
	public static $MdlObjects=array("MdlFaqSubject","MdlFaqMessage");

	/*
	 * ACTION PAR DEFAUT
	 */
	public static function actionDefault()
	{
		//Init
		$vDatas["themeList"]=MdlFaqTheme::getThemes();
		$vDatas["pageFullOrCenter"]="pageFull";
		////	AFFICHAGE D'UN SUJET & SES MESSAGES(?)
		$curSubject=Ctrl::getTargetObj();
		if(is_object($curSubject) && $curSubject::objectType=="faqSubject")
		{
			$curSubject->curUserConsultLastMessageMaj();//Met à jour si besoin la consultation du dernier message
			$vDatas["displayForum"]="subjectMessages";
			$vDatas["curSubject"]=$curSubject;
			$vDatas["messagesList"]=$curSubject->getMessages();
			$vDatas["messagesNb"]=count($vDatas["messagesList"]);
		}
		////	AFFICHAGE DES THÈMES DE SUJET
		elseif(!empty($vDatas["themeList"]) && Req::isParam("_idTheme")==false)
		{
			$vDatas["displayForum"]="theme";
			$vDatas["editTheme"]=MdlFaqTheme::addRight();
			if($vDatas["editTheme"]==false)  {$vDatas["pageFullOrCenter"]="pageCenter";}
			$vDatas["themeList"][]=new MdlFaqTheme(["undefinedTheme"=>true]);//ajoute le pseudo theme "sans theme"
			foreach($vDatas["themeList"] as $tmpKey=>$tmpTheme)
			{
				//Nombre de sujets & Objet du dernier sujet
				$sqlThemeFilter=(!empty($tmpTheme->_id)) ? "_idTheme=".$tmpTheme->_id : "_idTheme is NULL";//Theme normal / "sans theme"
				$tmpTheme->subjectList=Db::getObjTab("faqSubject", "SELECT * FROM ap_faqSubject WHERE ".MdlFaqSubject::sqlDisplayedObjects()." AND ".$sqlThemeFilter." ORDER BY dateCrea desc");
				$tmpTheme->subjectsNb=count($tmpTheme->subjectList);
				if($tmpTheme->undefinedTheme==true && empty($tmpTheme->subjectsNb))	{unset($vDatas["themeList"][$tmpKey]);}//Enleve le theme "sans theme" s'il n'y a aucun sujet correspondant..
				elseif($tmpTheme->subjectsNb>0)										{$tmpTheme->subjectLast=reset($tmpTheme->subjectList);}//reset: premier sujet de la liste (le + récent)
				//Nombre de messages & Dernier message : tous sujets confondus!
				$tmpTheme->messagesNb=$tmpTimeLastPost=0;
				foreach($tmpTheme->subjectList as $tmpSubject)
				{
					$messageList=$tmpSubject->getMessages();
					$tmpTheme->messagesNb+=count($messageList);
					if(!empty($messageList)){
						$lastMessage=reset($messageList);//1er message (le + récent)
						if($tmpTimeLastPost<strtotime($lastMessage->dateCrea))   {$tmpTheme->messageLast=$lastMessage;  $tmpTimeLastPost=strtotime($lastMessage->dateCrea);}//update la date du dernier message
					}
				}
			}
		}
		////	AFFICHAGE DES SUJETS (D'UN THEME SPECIFIQUE?)
		else
		{
			$vDatas["displayForum"]="subjects";
			$vDatas["editTheme"]=(empty($vDatas["themeList"]) && MdlFaqTheme::addRight());
			//Liste les sujets
			if(Req::getParam("_idTheme")=="undefinedTheme")	{$sqlThemeFilter="AND (_idTheme is NULL or _idTheme=0)";}		//sujets "sans theme"
			elseif(Req::isParam("_idTheme"))				{$sqlThemeFilter="AND _idTheme=".Db::formatParam("_idTheme");}	//sujets d'un theme précis
			else											{$sqlThemeFilter=null;}											//tout les sujets
			$sqlDisplayedSubjects="SELECT * FROM ".MdlFaqSubject::dbTable." WHERE ".MdlFaqSubject::sqlDisplayedObjects()." ".$sqlThemeFilter." ".MdlFaqSubject::sqlSort();
			$vDatas["subjectsDisplayed"]=Db::getObjTab("faqSubject", $sqlDisplayedSubjects." ".MdlFaqSubject::sqlPagination());
			$vDatas["subjectsTotalNb"]=count(Db::getTab($sqlDisplayedSubjects));
			//Pour chaque sujet : Nombre de messages & Dernier message
			foreach($vDatas["subjectsDisplayed"] as $tmpSubject){
				$messageList=$tmpSubject->getMessages();
				$tmpSubject->messagesNb=count($messageList);
				if(!empty($messageList))	{$tmpSubject->messageLast=reset($messageList);}//1er message (le + récent)
			}
		}
		////	THEME COURANT POUR LE MENU PATH
		if($vDatas["displayForum"]!="theme" && !empty($vDatas["themeList"])){
			if(Req::getParam("_idTheme")=="undefinedTheme" || (is_object($curSubject) && empty($curSubject->_idTheme)))	{$vDatas["curTheme"]=new MdlFaqTheme(["undefinedTheme"=>true]);}
			elseif(is_object($curSubject) && !empty($curSubject->_idTheme))												{$vDatas["curTheme"]=self::getObj("faqTheme",$curSubject->_idTheme);}
			elseif(Req::getParam("_idTheme"))																			{$vDatas["curTheme"]=self::getObj("faqTheme",Req::getParam("_idTheme"));}
		}
		////	AFFICHAGE
		static::$isMainPage=true;
		static::displayPage("VueIndexFaq.php",$vDatas);
	}

	/*
	 * PLUGINS
	 */
	public static function plugin($pluginParams)
	{
		$pluginsList=array();
		//Sujets
		foreach(MdlFaqSubject::getPluginObjects($pluginParams) as $objSubject)
		{
			$objSubject->pluginModule=self::moduleName;
			$objSubject->pluginIcon=self::moduleName."/icon.png";
			$objSubject->pluginLabel=(!empty($objSubject->title)) ? $objSubject->title : Txt::reduce($objSubject->description);
			$objSubject->pluginTitle=$objSubject->displayAutor(true,true);
			$objSubject->pluginJsIcon="redir('".$objSubject->getUrl()."',true);";
			$objSubject->pluginJsLabel=$objSubject->pluginJsIcon;
			$pluginsList[]=$objSubject;
		}
		//messages
		if($pluginParams["type"]!="shortcut")
		{
			foreach(MdlFaqMessage::getPluginObjects($pluginParams) as $objMessage)
			{
				$objMessage->pluginModule=self::moduleName;
				$objMessage->pluginIcon=self::moduleName."/icon.png";
				$objMessage->pluginLabel=(!empty($objMessage->title)) ? $objMessage->title : Txt::reduce($objMessage->description);
				$objMessage->pluginTitle=$objMessage->displayAutor(true,true);
				$objMessage->pluginJsIcon="redir('".$objMessage->getUrl("container")."',true);";
				$objMessage->pluginJsLabel=$objMessage->pluginJsIcon;
				$pluginsList[]=$objMessage;
			}
		}
		return $pluginsList;
	}

	/*
	 * AJAX : Active/désactive les notifications des messages par mail
	 */
	public static function actionNotifyLastMessage()
	{
		$curSubject=Ctrl::getTargetObj();
		if($curSubject->readRight()){
			$usersNotifyLastMessage=Txt::txt2tab($curSubject->usersNotifyLastMessage);
			if($curSubject->curUserNotifyLastMessage())		{$usersNotifyLastMessage=array_diff($usersNotifyLastMessage,[Ctrl::$curUser->_id]);		echo "removeUser";}
			else											{$usersNotifyLastMessage[]=Ctrl::$curUser->_id;											echo "addUser";}
			Db::query("UPDATE ap_faqSubject SET usersNotifyLastMessage=".Db::formatTab2txt($usersNotifyLastMessage)." WHERE _id=".$curSubject->_id);
		}
	}

	/*
	 * ACTION : Edition des themes de sujet
	 */
	public static function actionFaqThemeEdit()
	{
		////	Droit d'ajouter un theme?
		if(MdlFaqTheme::addRight()==false)  {static::lightboxClose(false);}
		////	Validation de formulaire
		if(Req::isParam("formValidate")){
			$curObj=Ctrl::getTargetObj();
			$curObj->controlEdit();
			//Modif d'un theme
			$_idSpaces=(!in_array("all",Req::getParam("spaceList")))  ?  Txt::tab2txt(Req::getParam("spaceList"))  :  null;
			$curObj->createUpdate("title=".Db::formatParam("title").", description=".Db::formatParam("description").", color=".Db::formatParam("color").", _idSpaces=".Db::format($_idSpaces));
			//Ferme la page
			static::lightboxClose();
		}
		////	Liste des themes
		$vDatas["themesList"]=MdlFaqTheme::getThemes(true);
		$vDatas["themesList"][]=new MdlFaqTheme();//nouveau theme vide
		foreach($vDatas["themesList"] as $tmpKey=>$tmpTheme){
			if($tmpTheme->editRight()==false)	{unset($vDatas["themesList"][$tmpKey]);}
			else{
				$tmpTheme->tmpId=$tmpTheme->_targetObjId;
				$tmpTheme->createdBy=($tmpTheme->isNew()==false)  ?  Txt::trad("creation")." : ".Ctrl::getObj("user",$tmpTheme->_idUser)->display()  :  null;
			}
		}
		////	Affiche la vue
		static::displayPage("VueFaqThemeEdit.php",$vDatas);
	}

	/*
	 * ACTION : Edition d'un sujet
	 */
	public static function actionFaqSubjectEdit()
	{
		//Init
		$curObj=Ctrl::getTargetObj();
		$curObj->controlEdit();
		if(MdlFaqSubject::addRight()==false)   {self::noAccessExit();}
		////	Formulaire validé
		if(Req::isParam("formValidate"))
		{
			//Enregistre & recharge l'objet
			$dateLastMessage=($curObj->isNew())  ?  ", dateLastMessage=".Db::dateNow()  :  null;//Init "dateLastMessage" pour un nouveau sujet (classement des sujets)
			$curObj=$curObj->createUpdate("title=".Db::formatParam("title").", description=".Db::formatParam("description","editor").", _idTheme=".Db::formatParam("_idTheme").", usersConsultLastMessage=".Db::formatTab2txt([Ctrl::$curUser->_id])." ".$dateLastMessage);
			//Notifie par mail & Ferme la page
			$mailNotif=Txt::reduce(strip_tags($curObj->description));
			if(!empty($curObj->title))	{$mailNotif=$curObj->title."<br><br>".$mailNotif;}
			$curObj->sendMailNotif($mailNotif);
			static::lightboxClose();
		}
		////	Affiche la vue
		$vDatas["curObj"]=$curObj;
		if(Req::isParam("_idTheme"))	{$curObj->_idTheme=Req::getParam("_idTheme");}
		$vDatas["themesList"]=MdlFaqTheme::getThemes();
		static::displayPage("VueFaqSubjectEdit.php",$vDatas);
	}

	/*
	 * ACTION : Edition d'un message
	 */
	public static function actionFaqMessageEdit()
	{
		//Init
		$curObj=Ctrl::getTargetObj();
		$curObj->controlEdit();
		////	Formulaire validé
		if(Req::isParam("formValidate")){
			//Enregistre & recharge l'objet
			$idMessageParent=(Req::isParam("_idMessageParent"))  ?  ", _idMessageParent=".Db::formatParam("_idMessageParent")  :  null;//Rattaché à un message parent?
			$curObj=$curObj->createUpdate("title=".Db::formatParam("title").", description=".Db::formatParam("description","editor").$idMessageParent);
			//MAJ "dateLastMessage" & "usersConsultLastMessage" du sujet conteneur
			Db::query("UPDATE ap_faqSubject SET dateLastMessage=".Db::dateNow().", usersConsultLastMessage=".Db::formatTab2txt([Ctrl::$curUser->_id])." WHERE _id=".$curObj->_idContainer);
			//Notifie par mail & Ferme la page
			$mailNotif=Txt::reduce(strip_tags($curObj->description));
			if(!empty($curObj->title))	{$mailNotif=$curObj->title."<br><br>".$mailNotif;}
			$notifUserIds=($curObj->isNewlyCreated())  ?  array_diff(Txt::txt2tab($curObj->containerObj()->usersNotifyLastMessage), [Ctrl::$curUser->_id])  :  null;//Ajoute les destinataires des notif "auto" si c'est un nouveau message (sauf pour l'auteur courant)
			$curObj->sendMailNotif($mailNotif, null, null, $notifUserIds);
			static::lightboxClose();
		}
		////	Affiche la vue
		$vDatas["curObj"]=$curObj;
		$vDatas["messageParent"]=(strlen(Req::getParam("_idMessageParent"))>0)  ?  self::getObj("faqMessage",Req::getParam("_idMessageParent"))  :  null;
		static::displayPage("VueFaqMessageEdit.php",$vDatas);
	}

	/*
	 * Image de l'auteur du sujet/message
	 */
	public static function autorImg($_idUser)
	{
		if(!empty($_idUser))	{return self::getObj("user",$_idUser)->getImg(true);}
	}
}
